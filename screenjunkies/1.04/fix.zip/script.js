defineClass('BKPPhoneRootViewController',{
	sidebarExpandTapped:function(sender){
		self.ORIGsidebarExpandTapped(sender);
		console.log("I Know You Want To Open The Side Bar:)");
	}
})