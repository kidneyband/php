defineClass('BKPPhoneRootViewController',{
	sidebarExpandTapped:function(sender){
		self.ORIGsidebarExpandTapped(sender);
	}
})