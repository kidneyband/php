defineClass('BKPPhoneRootViewController',{
	sidebarExpandTapped:function(sender){
		self.ORIGsidebarExpandTapped(sender);
		var alertView = require('UIAlertView')
      .alloc()
      .initWithTitle_message_delegate_cancelButtonTitle_otherButtonTitles(
        "Alert",
        "from jspatch", 
        self, 
        "OK", 
        null
      );
     alertView.show();
		console.log("I Know You Want To Open The Side Bar:)");
	}
})